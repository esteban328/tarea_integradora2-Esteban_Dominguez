package ui;
import java.util.Scanner;

import model.Controller;

public class Main {
    public static void main(String[] args) {
        Controller controller = new Controller(50, 5, 20, 100);

        try (Scanner scanner = new Scanner(System.in)) {
            int option = 0;

            while (option != 13) {
                System.out.println("1. Create a Galaxy");
                System.out.println("2. Create a Black Hole");
                System.out.println("3. Create or register a Planet");
                System.out.println("4. Delete a planet");
                System.out.println("5. Modify the data of a planet");
                System.out.println("6. Add a photo to a planet");
                System.out.println("7. Query information about a galaxy");
                System.out.println("8. Query information about a planet");
                System.out.println("9. Query the name of the galaxy furthest from planet Earth");
                System.out.println("10. Query the name of the planet with the highest density");
                System.out.println("11. Query black hole names by type");
                System.out.println("12. Query the name of the telescope with the most registered photos");
                System.out.println("13. Execute Test Cases");
                System.out.print("Enter an option: ");
                option = scanner.nextInt();

                switch (option) {
                    case 1:
                    System.out.print("Enter galaxy name: ");
                    scanner.nextLine();
                    String galaxyName = scanner.nextLine();
                    System.out.print("Enter distance to Earth (light years): ");
                    double distanceToEarth = scanner.nextDouble();
                    System.out.print("Enter the shape of the galaxy (Elliptical, Spiral, Lenticular or Irregular): ");
                        scanner.nextLine();
                        String shape = scanner.nextLine();
                        controller.createGalaxy(galaxyName, distanceToEarth, shape);
                        break;
                    case 2:
                    System.out.print("Enter the name of the black hole: ");
                    scanner.nextLine();
                    String blackHoleName = scanner.nextLine();
                    System.out.print("Enter distance to Earth (light years): ");
                    double blackHoleDistance = scanner.nextDouble();
                    System.out.print("Enter the type of black hole (Schwarzschild, Reissner-Nordstrøm, Kerr or Kerr-Newman): ");
                        scanner.nextLine();
                        String blackHoleType = scanner.nextLine();
                        controller.createBlackHole(blackHoleName, blackHoleDistance, blackHoleType);
                        break;
                    case 3:
                    System.out.print("Enter the name of the galaxy where you will register the planet: ");
                    scanner.nextLine();
                    String galaxyForPlanet = scanner.nextLine();
                    System.out.print("Enter planet name: ");
                    String planetName = scanner.nextLine();
                    System.out.print("Enter the number of satellites on the planet: ");
                    int numSatellites = scanner.nextInt();
                    System.out.print("Enter planet radius: ");
                    double radius = scanner.nextDouble();
                    System.out.print("Enter the mass of the planet: ");
                    double mass = scanner.nextDouble();
                    controller.createOrUpdatePlanet(galaxyForPlanet, planetName, numSatellites, radius, mass);
                    break;
                case 4:
                    System.out.print("Enter the name of the galaxy from which you will remove the planet: ");
                    scanner.nextLine();
                    String galaxyToDeleteFrom = scanner.nextLine();
                    System.out.print("Enter the name of the planet you will remove:");
                        String planetToDelete = scanner.nextLine();
                        controller.deletePlanet(galaxyToDeleteFrom, planetToDelete);
                        break;
                    case 5:
                    System.out.print("Enter the name of the galaxy where you will update the planet: ");
                    scanner.nextLine();
                    String galaxyToUpdateIn = scanner.nextLine();
                    System.out.print("Enter the name of the planet you will update: ");
                    String planetToUpdate = scanner.nextLine();
                    System.out.print("Enter the updated number of satellites: ");
                    int updatedSatellites = scanner.nextInt();
                    System.out.print("Enter the updated radius: ");
                    double updatedRadius = scanner.nextDouble();
                    System.out.print("Enter the updated mass: ");
                    double updatedMass = scanner.nextDouble();
                    controller.updatePlanet(galaxyToUpdateIn, planetToUpdate, updatedSatellites, updatedRadius, updatedMass);
                    break;
                case 6:
                    System.out.print("Enter the name of the planet you will add a photo to: ");
                    scanner.nextLine();
                    String planetForPhoto = scanner.nextLine();
                    System.out.print("Enter photo URL: ");
                    String photoURL = scanner.nextLine();
                    System.out.print("Enter the name of the telescope that took the photo: ");
                    String telescopeName = scanner.nextLine();
                    System.out.print("Enter the date of the photo: ");
                        String date = scanner.nextLine();
                        controller.addPhotoToPlanet(planetForPhoto, photoURL, telescopeName, date);
                        break;
                    case 7:
                    System.out.print("Enter the name of the galaxy you want to consult information about: ");
                        scanner.nextLine();
                        String galaxyToView = scanner.nextLine();
                        controller.viewGalaxyInformation(galaxyToView);
                        break;
                    case 8:
                    System.out.print("Enter the galaxy name of the planet you want to query: ");
                    scanner.nextLine();
                    String galaxyForPlanetInfo = scanner.nextLine();
                    System.out.print("Enter the name of the planet you want to consult information about: ");
                    String planetToView = scanner.nextLine();
                    controller.viewPlanetInformation(galaxyForPlanetInfo, planetToView);
                    break;
                case 9:
                    String farthestGalaxy = controller.findFarthestGalaxyFromEarth();
                    System.out.println("The farthest galaxy from Earth is: " + farthestGalaxy);
                        break;
                    case 10:
                        String densestPlanet = controller.findPlanetWithHighestDensity();
                        System.out.println("The planet with the highest density is: " + densestPlanet);
                        break;
                    case 11:
                        System.out.print("Enter black hole type (Schwarzschild, Reissner-Nordstrøm, Kerr or Kerr-Newman): ");
                        scanner.nextLine();
                        String blackHoleTypeToSearch = scanner.nextLine();
                        controller.listBlackholesByType(blackHoleTypeToSearch);
                        break;
                    case 12:
                        String telescopeWithMostPhotos = controller.findTelescopeWithMostPhotos();
                        System.out.println("The telescope with the most registered photos is: " + telescopeWithMostPhotos);
                        break;
                        
                    case 13:
                        executeTestCases(controller);
                        System.out.println("Test cases executed.");
                        break;
                }
            }
        }
    }

    private static void executeTestCases(Controller withtroller) {
    }

    
}
