package model;

public class Photo {
    private String url;
    private String telescopeName;
    private String date;

    public Photo(String url, String telescopeName, String date) {
        this.url = url;
        this.telescopeName = telescopeName;
        this.date = date;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTelescopeName() {
        return telescopeName;
    }

    public void setTelescopeName(String telescopeName) {
        this.telescopeName = telescopeName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

   
}
