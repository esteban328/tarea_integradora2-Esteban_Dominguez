package model;

public class galaxy {
    private String name;
    private double distanceToEarth;
    private String shape;
    private Photo[] photos;
    private Blackhole Blackhole;

    
    private static int galaxyCount = 0;

    private static final int MAX_GALAXIES = 50;
    private static final int MAX_PHOTOS = 30;

    public static final String[] SHAPE_CHOICES = {"Eliptical", "Espiral", "Lenticular", "Irregular"};

    public galaxy(String name, double distanceToEarth, String shape, int maxBlackholePhotos) {
        if (galaxyCount < MAX_GALAXIES) {
            this.name = name;
            this.distanceToEarth = distanceToEarth;
            this.shape = shape;
            this.photos = new Photo[MAX_PHOTOS];
            this.Blackhole = new Blackhole(maxBlackholePhotos);
            galaxyCount++; 
        } else {
            System.out.println("¡The maximum limit of 50 galaxies has been reached!");
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDistanceToEarth() {
        return distanceToEarth;
    }

    public void setDistanceToEarth(double distanceToEarth) {
        this.distanceToEarth = distanceToEarth;
    }

    public String getShape() {
        return shape;
    }

    public void setShape(String shape) {
        this.shape = shape;
    }

    public Photo[] getPhotos() {
        return photos;
    }

    public Blackhole getBlackhole() {
        return Blackhole;
    }

}