package model;

public class planet {
    private String name;
    private int numSatellites;
    private double radius;
    private double mass;
    private Photo[] photos;

    public planet(String name, int numSatellites, double radius, double mass, int maxPhotos) {
        this.name = name;
        this.numSatellites = numSatellites;
        this.radius = radius;
        this.mass = mass;
        this.photos = new Photo[maxPhotos];
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumSatellites() {
        return numSatellites;
    }

    public void setNumSatellites(int numSatellites) {
        this.numSatellites = numSatellites;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public Photo[] getPhotos() {
        return photos;
    }

    public double calculateVolume() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
    }

    public double calculateDensity() {
        return mass / calculateVolume();
    }

    public void addPhoto(Photo newPhoto) {
        for (int i = 0; i < photos.length; i++) {
            if (photos[i] == null) {
                photos[i] = newPhoto;
                break; 
            }
        }
    }

    public String getGalaxy() {
        return null;
    }

    public int getPhotoCount() {
        int count = 0;
        for (Photo photo : photos) {
            if (photo != null) {
                count++;
            }
        }
        return count;
    }
}
