package model;

public class Blackhole {
    private String name;
    private double mass;
    private double distanceToEarth;
    private String type;
    private String[] photoUrls;

    private static int BlackholeCount = 0;

    private static final int MAX_BLACK_HOLES = 5;
    private static final int MAX_PHOTOS = 5;

    public static final String[] BLACK_HOLE_TYPES = {
        "Schwarzschild", "Reissner-Nordstrøm", "Kerr", "Kerr-Newman"
    };

    public Blackhole(String name, double mass, double distanceToEarth, String type) {
        if (BlackholeCount < MAX_BLACK_HOLES) {
            this.name = name;
            this.mass = mass;
            this.distanceToEarth = distanceToEarth;
            this.type = type;
            this.photoUrls = new String[MAX_PHOTOS];
            BlackholeCount++;
        } else {
            System.out.println("¡The maximum limit of 5 black holes has been reached!");
        }
    }

    public Blackhole(int maxBlackholePhotos) {
    }

    public Blackhole(String name2, double distanceToEarth2, String type2, int i) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public double getDistanceToEarth() {
        return distanceToEarth;
    }

    public void setDistanceToEarth(double distanceToEarth) {
        this.distanceToEarth = distanceToEarth;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String[] getPhotoUrls() {
        return photoUrls;
    }

    public void setPhotoUrls(String[] photoUrls) {
        this.photoUrls = photoUrls;
    }

    public galaxy getGalaxy() {
        return null;
    }
}
