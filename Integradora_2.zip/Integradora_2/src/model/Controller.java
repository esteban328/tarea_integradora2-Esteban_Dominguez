package model;

public class Controller {
    private galaxy[] galaxies;
    private Blackhole[] blackHoles;
    private planet[] planets;
    private Photo[] photos;
    private int galaxyCount = 0;
    private int blackHoleCount = 0;
    private int planetCount = 0;
    private int photoCount = 0;

    public Controller(int maxGalaxies, int maxBlackHoles, int maxPlanets, int maxPhotos) {
        galaxies = new galaxy[maxGalaxies];
        blackHoles = new Blackhole[maxBlackHoles];
        planets = new planet[maxPlanets];
        photos = new Photo[maxPhotos];
    }

    public void createGalaxy(String name, double distanceToEarth, String shape) {
        if (galaxyCount < galaxies.length) {
            galaxies[galaxyCount] = new galaxy(name, distanceToEarth, shape, 30);
            galaxyCount++;
        } else {
            System.out.println("The galaxy limit has been reached!");
        }
    }

    public void createBlackHole(String name, double distanceToEarth, String type) {
        if (blackHoleCount < blackHoles.length) {
            blackHoles[blackHoleCount] = new Blackhole(name, distanceToEarth, type, 5);
            blackHoleCount++;
        } else {
            System.out.println("The limit of black holes has been reached!");
        }
    }

    public void createOrUpdatePlanet(String galaxyName, String planetName, int numSatellites, double radius, double mass) {
        galaxy targetGalaxy = findGalaxyByName(galaxyName);

        if (targetGalaxy != null) {
            if (planetCount < planets.length) {
                int planetIndex = findPlanetIndexByName(targetGalaxy, planetName);
                if (planetIndex == -1) {
                    planets[planetCount] = new planet(planetName, numSatellites, radius, mass, 50);
                    planetCount++;
                } else {
                    planet existingPlanet = planets[planetIndex];
                    existingPlanet.setNumSatellites(numSatellites);
                    existingPlanet.setRadius(radius);
                    existingPlanet.setMass(mass);
                }
            } else {
                System.out.println("Planet limit reached!");
            }
        } else {
            System.out.println("The specified galaxy was not found.");
        }
    }

    public void deletePlanet(String galaxyName, String planetName) {
        galaxy targetGalaxy = findGalaxyByName(galaxyName);
        if (targetGalaxy != null) {
            int index = findPlanetIndexByName(targetGalaxy, planetName);
            if (index != -1) {
                for (int i = index; i < planetCount - 1; i++) {
                    planets[i] = planets[i + 1];
                }
                planets[planetCount - 1] = null;
                planetCount--;
                System.out.println("The planet '" + planetName + "' has been removed from the galaxy '" + galaxyName + "'.");
            } else {
                System.out.println("Planet not found '" + planetName + "' in the galaxy '" + galaxyName + "'.");
            }
        } else {
            System.out.println("Galaxy not found '" + galaxyName + "'.");
        }
    }

    public void addPhotoToPlanet(String planetName, String url, String telescopeName, String date) {
        int planetIndex = findPlanetIndexByName(planetName);
        if (planetIndex != -1) {
            planet planet = planets[planetIndex];
            if (planet.getPhotoCount() < planet.getPhotos().length) {
                Photo newPhoto = new Photo(url, telescopeName, date);
                planet.addPhoto(newPhoto);
                photos[photoCount] = newPhoto;
                photoCount++;
            } else {
                System.out.println("The photo limit for this planet has been reached!");
            }
        } else {
            System.out.println("The specified planet was not found.");
        }
    }

    private int findPlanetIndexByName(String planetName) {
        return 0;
    }

    public void updatePlanet(String galaxyName, String planetName, int numSatellites, double radius, double mass) {
        galaxy targetGalaxy = findGalaxyByName(galaxyName);
        if (targetGalaxy != null) {
            int index = findPlanetIndexByName(targetGalaxy, planetName);
            if (index != -1) {
                planet planet = planets[index];
                planet.setNumSatellites(numSatellites);
                planet.setRadius(radius);
                planet.setMass(mass);
            } else {
                System.out.println("The required planet was not found.");
            }
        } else {
            System.out.println("The required galaxy was not found.");
        }
    }

    public void viewGalaxyInformation(String galaxyName) {
        galaxy targetGalaxy = findGalaxyByName(galaxyName);
        if (targetGalaxy != null) {
            System.out.println(targetGalaxy.toString());
            for (Photo photo : targetGalaxy.getPhotos()) {
                if (photo != null) {
                    System.out.println(photo.toString());
                }
            }
        } else {
            System.out.println("The specified galaxy was not found.");
        }
    }

    public void viewPlanetInformation(String galaxyName, String planetName, galaxy targetPlanet) {
        galaxy targetGalaxy = findGalaxyByName(galaxyName);
        if (targetGalaxy != null) {
            int targetPlanetIndex = findPlanetIndexByName(targetGalaxy, planetName);
            if (targetPlanetIndex != -1) {
                System.out.println(targetPlanet.toString());
                for (int i = 0; i < targetPlanet.getPhotos().length; i++) {
                    Photo photo = targetPlanet.getPhotos()[i];
                    if (photo != null) {
                        System.out.println(photo.toString());
                    }
                }
            } else {
                System.out.println("The specified planet was not found.");
            }
        } else {
            System.out.println("The specified galaxy was not found.");
        }
    }

    public String findFarthestGalaxyFromEarth() {
        double maxDistance = 0.0;
        String farthestGalaxy = "";

        for (int i = 0; i < galaxyCount; i++) {
            if (galaxies[i].getDistanceToEarth() > maxDistance) {
                maxDistance = galaxies[i].getDistanceToEarth();
                farthestGalaxy = galaxies[i].getName();
            }
        }

        return farthestGalaxy;
    }

    public String findPlanetWithHighestDensity() {
        double maxDensity = 0.0;
        String densestPlanet = "";

        for (int i = 0; i < planetCount; i++) {
            planet planet = planets[i];
            double volume = (4.0 / 3.0) * Math.PI * Math.pow(planet.getRadius(), 3);
            double density = planet.getMass() / volume;

            if (density > maxDensity) {
                maxDensity = density;
                densestPlanet = planet.getName();
            }
        }

        return densestPlanet;
    }

    public String findTelescopeWithMostPhotos() {
        String telescopeWithMostPhotos = "";
        int maxPhotos = 0;

        for (int i = 0; i < planetCount; i++) {
            planet planet = planets[i];
            for (int j = 0; j < planet.getPhotoCount(); j++) {
                if (planet.getPhotos()[j] != null) {
                    String telescopeName = planet.getPhotos()[j].getTelescopeName();
                    int telescopePhotoCount = countTelescopePhotos(telescopeName);

                    if (telescopePhotoCount > maxPhotos) {
                        maxPhotos = telescopePhotoCount;
                        telescopeWithMostPhotos = telescopeName;
                    }
                }
            }
        }

        return telescopeWithMostPhotos;
    }

    private galaxy findGalaxyByName(String name) {
        for (int i = 0; i < galaxyCount; i++) {
            if (galaxies[i].getName().equals(name)) {
                return galaxies[i];
            }
        }
        return null;
    }

    private int findPlanetIndexByName(galaxy targetGalaxy, String planetName) {
        for (int i = 0; i < planetCount; i++) {
            if (planets[i].getName().equals(planetName) && planets[i].getGalaxy().equals(targetGalaxy)) {
                return i;
            }
        }
        return -1;
    }

    private int countTelescopePhotos(String telescopeName) {
        int count = 0;

        for (int i = 0; i < planetCount; i++) {
            planet planet = planets[i];
            for (int j = 0; j < planet.getPhotoCount(); j++) {
                if (planet.getPhotos()[j] != null && planet.getPhotos()[j].getTelescopeName().equals(telescopeName)) {
                    count++;
                }
            }
        }

        return count;
    }

    public void viewPlanetInformation(String galaxyForPlanetInfo, String planetToView) {
    }

    public void listBlackholesByType(String type) {
        for (int i = 0; i < blackHoleCount; i++) {
            if (blackHoles[i].getType().equalsIgnoreCase(type)) {
                System.out.println("Galaxy: " + blackHoles[i].getGalaxy().getName());
                System.out.println("Black Hole: " + blackHoles[i].getName());
            }
        }
    }

    public void runTestCases() {
        Controller controller = new Controller(10, 10, 10, 10);

        // Caso 1:
        controller.createGalaxy("prures", 2000000, "Epiral");

        // Caso 2:
        controller.createBlackHole("Black Hole 1", 50000, "Type A");

        // Caso 3:
        controller.createOrUpdatePlanet("prures", "Mars", 5, 330, 5541.71e21);

        // Caso 4:
        controller.addPhotoToPlanet("Mars", "mars_photo.jpg", "Telescope r", "2023-20-02");

        // Caso 5:
        controller.viewGalaxyInformation("prures");

        // Caso 6:
        controller.viewPlanetInformation("prures", "Mars");

        // Caso 7:
        controller.deletePlanet("prures", "Mars");

        // Caso 8:
        controller.viewPlanetInformation("prures", "Mars");

        // Caso 9:
        String farthestGalaxy = controller.findFarthestGalaxyFromEarth();
        System.out.println("Galaxia más lejana de la Tierra: " + farthestGalaxy);

        // Caso 10:
        String densestPlanet = controller.findPlanetWithHighestDensity();
        System.out.println("Planeta más denso: " + densestPlanet);

        // Caso 11:
        controller.listBlackholesByType("Type A");

        // Caso 12:
        String telescopeWithMostPhotos = controller.findTelescopeWithMostPhotos();
        System.out.println("Telescopio con más fotos: " + telescopeWithMostPhotos);
    }
}
